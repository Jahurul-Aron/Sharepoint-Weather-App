﻿$(document).ready(function () {
    $('#searchUser').on('keyup', function (e) {
        var cityname = e.target.value;
        //console.log(cityname);
        $.ajax({
            url: 'http://api.apixu.com/v1/current.json?key=fce8256d9f3149848ec184105170404&q=' + cityname,
            //<h3 class="panel-title">${city.current.condition.icon}</h3>
        }).done(function (city) {
            // console.log(city);
            //  $('#profile').append('<img src= "'+city.current.condition.attr("https").icon+'">');	
            // $('#profile').html((city.current.condition).https.icon);
            $('#profile').html(`
       
           
        <div class="panel panel-default">
         <h3 class="panel-title">Current weather information</h3>
          <div class="panel-heading">
             <p> <img src="${city.current.condition.icon}"></p>
            <h3 class="panel-title">${city.location.name}</h3>
            <h3 class="panel-title">${city.location.region}</h3>
             <h3 class="panel-title">${city.location.country}</h3>
             <h2 class="panel-title">${city.location.localtime}</h2>
          </div>
          <div class="panel-body">
         
              
              
              <ul class="list-group">
                <li class="list-group-item">Current temp: ${city.current.temp_c}</li>
                <li class="list-group-item"> Condition: ${city.current.condition.text}</li>
             
                <li class="list-group-item">Feeling temp: ${city.current.feelslike_c}</li>
                <li class="list-group-item">Humidity: ${city.current.humidity}</li>
              </ul>
              
            </div>
          </div>
      
        
      `);
        });

        //second forecast news by city
        $.ajax({
            url: 'http://api.apixu.com/v1/forecast.json?key=fce8256d9f3149848ec184105170404&q=' + cityname,
            //<h3 class="panel-title">${city.current.condition.icon}</h3>
        }).done(function (cit) {
            // console.log(city);
            // $('#profile').html((city.current.condition).https.icon);
            $('#profile1').html(`
       
        <div class="panel panel-default">
         <h3 class="panel-title">Current weather forecast</h3>
         
           <div class="panel-body">
         
              
              
              <ul class="list-group">
                <li class="list-group-item">Max temp today: ${cit.forecast.forecastday[0].day.maxtemp_c}</li>
                <li class="list-group-item"> Min Temp today: ${cit.forecast.forecastday[0].day.mintemp_c}</li>
             
                <li class="list-group-item">Sunrise today: ${cit.forecast.forecastday[0].astro.sunrise}</li>
                <li class="list-group-item">Sunset today: ${cit.forecast.forecastday[0].astro.sunset}</li>
                  <li class="list-group-item">Moonrise today: ${cit.forecast.forecastday[0].astro.moonrise}</li>
                   <li class="list-group-item">Moonset today: ${cit.forecast.forecastday[0].astro.moonset}</li>
              </ul>
              
            </div>
            </div>
       
      
        
      `);
        });
    });//for varivle
});
